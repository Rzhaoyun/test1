
-- ----------------------------
-- Records of user_usersperfer
-- ----------------------------
INSERT INTO `user_usersperfer` VALUES (10, '乐器');
INSERT INTO `user_usersperfer` VALUES (9, '书法');
INSERT INTO `user_usersperfer` VALUES (11, '养花');
INSERT INTO `user_usersperfer` VALUES (8, '品茶');
INSERT INTO `user_usersperfer` VALUES (16, '唱歌');
INSERT INTO `user_usersperfer` VALUES (20, '宠物');
INSERT INTO `user_usersperfer` VALUES (13, '摄影');
INSERT INTO `user_usersperfer` VALUES (4, '游泳');
INSERT INTO `user_usersperfer` VALUES (15, '烘焙');
INSERT INTO `user_usersperfer` VALUES (17, '电影');
INSERT INTO `user_usersperfer` VALUES (5, '登山');
INSERT INTO `user_usersperfer` VALUES (12, '看书');
INSERT INTO `user_usersperfer` VALUES (3, '篮球');
INSERT INTO `user_usersperfer` VALUES (19, '绘画');
INSERT INTO `user_usersperfer` VALUES (18, '美食');
INSERT INTO `user_usersperfer` VALUES (6, '羽毛球');
INSERT INTO `user_usersperfer` VALUES (2, '足球');
INSERT INTO `user_usersperfer` VALUES (1, '跑步');
INSERT INTO `user_usersperfer` VALUES (14, '郊游');
INSERT INTO `user_usersperfer` VALUES (7, '钓鱼');
