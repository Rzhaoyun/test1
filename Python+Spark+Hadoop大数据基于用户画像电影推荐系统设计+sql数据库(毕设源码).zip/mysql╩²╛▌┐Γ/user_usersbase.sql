
-- ----------------------------
-- Records of user_usersbase
-- ----------------------------
INSERT INTO `user_usersbase` VALUES (1, 'Zero', 'e10adc3949ba59abbe56e057f20f883e', '2', '1', '1', '18888888881', 'static/images/avatars/7e6ae4a1fbd4483c831105e18574d888.jpg', 'Admin', '1@qq.com', 3);
INSERT INTO `user_usersbase` VALUES (2, 'Visitor', 'e10adc3949ba59abbe56e057f20f883e', '1', '0', '1', '18888888888', 'static/images/user.jpg', 'Admin', 'visiter@qq.com', 3);
