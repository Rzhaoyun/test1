from django.apps import AppConfig


class BisheConfig(AppConfig):
    name = 'BiShe'
