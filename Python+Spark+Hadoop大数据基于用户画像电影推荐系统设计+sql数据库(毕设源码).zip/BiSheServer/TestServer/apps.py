from django.apps import AppConfig


class TestserverConfig(AppConfig):
    name = 'TestServer'
